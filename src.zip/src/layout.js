// in src/MyLayout.js
import React from 'react';
import { Layout } from 'react-admin';
import menu from './menu';

export const MyLayout = (props) => <Layout {...props} menu={menu} />;
