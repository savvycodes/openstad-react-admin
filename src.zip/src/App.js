import React from 'react';
import logo from './logo.svg';
import './App.css';
import { Admin, Resource, fetchUtils} from 'react-admin';
import { Route } from 'react-router-dom';
import simpleRestProvider from 'ra-data-simple-rest';
import { ArticleList, ArticleEdit, ArticleCreate, ArticleIcon } from './article';
import { OrderList, OrderEdit, OrderCreate, OrderIcon } from './order';
import { UserList, UserEdit, UserCreate, UserIcon } from './user';
import { IdeaList, IdeaEdit, IdeaCreate, IdeaIcon } from './idea';
import { ProductList, ProductEdit, ProductCreate, ProductIcon } from './product';
import { SettingsForm } from './profile';
import { MyLayout } from './layout';
import Dashboard from './Dashboard';
import dataProvider from './dataProvider';

function App(props) {
  const resources = props.resources;
  const user = props.user;
  const userPath = "/user/" + user.id;

  return (
    <Admin
        dashboard={Dashboard}
        dataProvider={dataProvider(props.jwt)}
        appLayout={MyLayout}
        customRoutes={[
            <Route exact path={userPath} render={() => <SettingsForm />} />,
        ]}
    >
      {resources.product && resources.product.active ? <Resource name="product" list={ProductList} edit={ProductEdit} create={ProductCreate} icon={ProductIcon} options={{menuTitle: 'Jouw producten'}} /> : <div />}
      {resources.order && resources.order.active ? <Resource name="order" list={OrderList} edit={OrderEdit} create={OrderCreate} icon={OrderIcon} options={{menuTitle: 'Jouw bestellingen'}} /> : <div />}
      {resources.user && resources.user.active ? <Resource name="user" list={UserList} edit={UserEdit} create={UserCreate} icon={UserIcon} options={{userPath: userPath, hideMenulink: true}} /> : <div />}
      {resources.idea && resources.idea.active ?  <Resource name="idea" list={IdeaList} edit={IdeaEdit} create={IdeaCreate} icon={IdeaIcon} options={{menuTitle: 'Ideas'}} />  : <div />}
      {resources.article && resources.article.active ?  <Resource name="article" list={ArticleList} edit={ArticleEdit} create={ArticleCreate} icon={ArticleIcon} />  : <div />}
    </Admin>
  );
}

export default App;
