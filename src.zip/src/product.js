// in posts.js
import React from 'react';
import { List, NumberField, Datagrid, Edit, Create, SimpleForm, DateField, TextField, EditButton, TextInput, DateInput, ImageInput, ImageField } from 'react-admin';
import ListAltIcon from '@material-ui/icons/ListAlt';
export const ProductIcon = ListAltIcon;

export const ProductList = (props) => (
    <List {...props}>
        <Datagrid>
            <TextField source="sku" />
            <TextField source="name" />
            <TextField source="regular_price" />
            <EditButton basePath="/product" />
        </Datagrid>
    </List>
);

const ProductTitle = ({ record }) => {
    return <span>Product {record ? `"${record.title}"` : ''}</span>;
};

export const ProductEdit = (props) => (
    <Edit title={<ProductTitle />} {...props}>
        <SimpleForm>
          <ImageInput source="images" label="Related images" accept="image/*">
            <ImageField source="src" title="title" />
          </ImageInput>
          <TextInput source="sku" />
          <TextInput source="name" />
          <TextInput multiline source="description" />
          <NumberField source="regular_price" options={{ style: 'currency', currency: 'EUR' }} />
        </SimpleForm>
    </Edit>
);

export const ProductCreate = (props) => (
    <Create title="Product toevoegen" {...props}>
        <SimpleForm>
            <ImageInput source="images" label="Related images" accept="image/*">
              <ImageField source="src" title="title" />
            </ImageInput>
            <TextInput source="sku" />
            <TextInput source="name" />
            <TextInput multiline source="description" />
            <NumberField source="regular_price" options={{ style: 'currency', currency: 'EUR' }} />
        </SimpleForm>
    </Create>
);
